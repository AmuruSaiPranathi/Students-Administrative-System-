<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

<link href="//netdna.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//netdna.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-2.1.3.min.js"></script>
<!------ Include the above in your HEAD tag ---------->
<style>
body {
background-image: url(images/studentregistration.jpg); 
background-size: cover ;
background-repeat: no-repeat;
}
</style>
<div class="container">
            <form class="form-horizontal" role="form" method="POST" action="connect1.php">
			
                <h2 align="center">Student Registration</h2><br><br>
                <div class="form-group">
                    <label for="firstName" class="col-sm-3 control-label">Name*</label>
                    <div class="col-sm-9">
                        <input type="text" name="name" placeholder="Student Name" class="form-control" autofocus>
                    </div>
                </div>
                <div class="form-group">
                    <label for="lastName" class="col-sm-3 control-label">Roll No*</label>
                    <div class="col-sm-9">
                        <input type="text" name="rollno" placeholder="Roll No." class="form-control" autofocus>
                    </div>
                </div>
                <div class="form-group">
                    <label for="email" class="col-sm-3 control-label">Email* </label>
                    <div class="col-sm-9">
                        <input type="email" name="email" placeholder="Email" class="form-control" name= "email">
                    </div>
                </div>
                <div class="form-group">
                    <label for="password" class="col-sm-3 control-label">Password*</label>
                    <div class="col-sm-9">
                        <input type="password" name="password" placeholder="Password" class="form-control">
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="birthDate" class="col-sm-3 control-label">Date of Birth*</label>
                    <div class="col-sm-9">
                        <input type="date" name="dob" class="form-control">
                    </div>
                </div>
                <div class="form-group">
                    <label for="phoneNumber" class="col-sm-3 control-label">Phone number </label>
                    <div class="col-sm-9">
                        <input type="phoneNumber" name="phone" placeholder="Phone number" class="form-control">
                        
                    </div>
                </div>
                <div class="form-group">
                        <label for="Height" class="col-sm-3 control-label">Department </label>
                    <div class="col-sm-9">
                        <select class="form-control" name="dept" placeholder="Department">
							<option value="">Department</option>
							<option value="CE">CEVIL</option>
							<option value="EEE">EEE</option>
							<option value="ME">MECH</option>
							<option value="ECE">ECE</option>
							<option value="CSE">CSE</option>
							<option value="IT">IT</option>
						</select>
                       
						
						
                    </div>
                </div>
                 <div class="form-group">
                        <label for="weight" class="col-sm-3 control-label">Year </label>
                    <div class="col-sm-9">
                        <input type="number" name="year" placeholder="" class="form-control">
                    </div>
                </div>
				<!--<div class="form-group">
                        <label for="weight" class="col-sm-3 control-label">Sem </label>
                    <div class="col-sm-9">
                        <input type="number" name="sem" placeholder="" class="form-control">
                    </div>
                </div> -->
				<div class="form-group">
                        <label for="Height" class="col-sm-3 control-label">Sem </label>
                    <div class="col-sm-9">
                        <select class="form-control" name="sem" placeholder="Department">
							<option value="I"> I SEM</option>
							<option value="II">II SEM</option>
							
						</select>
                       
						
						
                    </div>
                </div>
                <div class="form-group">
                    <label class="control-label col-sm-3">Gender</label>
                    <div class="col-sm-6">
                        <div class="row">
                            <div class="col-sm-4">
                                <label class="radio-inline">
                                    <input type="radio" name="gen" value="Female">Female
                                </label>
                            </div>
                            <div class="col-sm-4">
                                <label class="radio-inline">
                                    <input type="radio" name="gen" value="Male">Male
                                </label>
                            </div>
                        </div>
                    </div>
                </div> 
				</div><!-- /.form-group -->
               <div class="col-4">
                <button  type="submit" name="submit" class="btn btn-primary btn-block">Register</button>
            </form> <!-- /form -->
        </div>
		<!-- ./container -->