<?php

$ndname = filter_input(INPUT_POST, 'ndname');
$status = filter_input(INPUT_POST, 'status');

//if(!empty($rollno)){
//if(!empty($name)){
$host = "localhost";
$dbusername = "root";
$dbpassword = "";
$dbname = "project2";

$conn = new mysqli ($host, $dbusername, $dbpassword, $dbname);

if(mysqli_connect_error()){
	die('Connect Error('.mysqli_connect_errno().')'
	.mysqli_connect_error());
}
else {
//	$sql = "INSERT INTO placement (rollno, name, branch, company, year) values ('$rollno','$name','$branch','$company', '$year')";
	
  $sql=	"INSERT INTO `nodueform`(`ndname`, `status`) VALUES ('$ndname','$status')";
	
	if($conn->query($sql)){
		echo "Suuccessfully record the data";
	}
	else {
		echo "Error:".$sql."<br>".$conn->error;
		
	}	
$conn->close();	
}