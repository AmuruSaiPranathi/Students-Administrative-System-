<?php

$name = filter_input(INPUT_POST, 'name');
//$rollno = filter_input(INPUT_POST, 'rollno');
$email = filter_input(INPUT_POST, 'email');
$password = filter_input(INPUT_POST, 'password');
//$dob = filter_input(INPUT_POST, 'dob');
$phone = filter_input(INPUT_POST, 'phone');
$subject = filter_input(INPUT_POST, 'subject');
//$year = filter_input(INPUT_POST, 'year');
//$sem = filter_input(INPUT_POST, 'sem');
$gender = filter_input(INPUT_POST, 'gender');


//if(!empty($rollno)){
//if(!empty($name)){
$host = "localhost";
$dbusername = "root";
$dbpassword = "";
$dbname = "project2";

$conn = new mysqli ($host, $dbusername, $dbpassword, $dbname);

if(mysqli_connect_error()){
	die('Connect Error('.mysqli_connect_errno().')'
	.mysqli_connect_error());
}
else {
//	$sql = "INSERT INTO placement (rollno, name, branch, company, year) values ('$rollno','$name','$branch','$company', '$year')";
	
 // $sql=	"INSERT INTO `placement`(`rollno`, `name`, `branch`, `company`, `year`) VALUES ('$rollno','$name','$branch','$company','$year')";
	
	$sql="INSERT INTO `facultyreg`(`name`, `email`, `password`, `phone`, `subject`, `gender`) VALUES ('$name','$email','$password','$phone', '$subject', '$gender')";
	
//	echo "success";
	
	if($conn->query($sql)){
		
	header("Location:faculty_login.php");
		
}
else {
	echo "Error:".$sql."<br>".$conn->error;
		
}	
$conn->close();	
}
	
?>