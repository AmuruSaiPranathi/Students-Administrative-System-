<html>
<form action="nodueconnect1.php" method="post">
<head>
<style>
body {
  margin: 0;
  background: url(images/noduepage.jpg);
  background-size: cover ;
  background-repeat: no-repeat;
}
a{
  text-decoration: none;
}
.sendrequest {
  color: #FFF;
  background: #1a1aff;
  padding: 15px 20px;
  box-shadow: 0 4px 0 0 #2EA62E;
}
.sendrequest:hover {
  background: #8080ff;
  box-shadow: 0 4px 0 0 #7ED37E;
}
.accept {
  color: #FFF;
  background: #44CC44;
  padding: 15px 20px;
  box-shadow: 0 4px 0 0 #2EA62E;
}
.accept:hover {
  background: #6FE76F;
  box-shadow: 0 4px 0 0 #7ED37E;
}
.deny {
  color: #FFF;
  background: tomato;
  padding: 15px 20px;
  box-shadow: 0 4px 0 0 #CB4949;
}
.deny:hover {
  background: rgb(255, 147, 128);
  box-shadow: 0 4px 0 0 #EF8282;
}
</style>
</head>
<body>
<center>
<h1><font color="", style="cursive">Rajeev Gandhi Memorial College of Engineering and Technology</font></h1>
</br>
</br>
<h2> NO DUE FORM </h2>

<table cellpadding="5px" cellspacing="15px">
<tr>
<td> </td>
<td> </td>
<td> </td>
<td> </td>
<tr>
<td><font size="5px">Name of The Student</font> </td>
<td colspan="3"><center><input type="text" name="ndname" placeholder="Name" /></center> </td>
</tr>
<tr>
<td> <font size="5px">Registration Number </font></td>
<td colspan="3"><center><input type="text" name="ndrollno" placeholder="Roll.no" /></center> </td>
</tr>
<tr>
<td> <font size="5px">Phone Number </font> </td>
<td colspan="3"> <center><input type="text" name="ndphone" placeholder="Mobile Number"/> </center></td>
</tr>
<tr>
<td> <font size="5px">Year </font> </td>
<td colspan="3"> <center><input type="text" name="ndyear" placeholder="Year of Study"/> </center></td>
</tr>
<tr>
<td> <font size="5px"> Branch </font> </td>
<td colspan="3"> <center> <input type="text" name="ndbranch" placeholder="Branch"/> </center></td>
</tr>
<tr>
<td> <font size="5px">Sem </font> </td> 
<td> 
<center><input type="radio" name="ndsem">I</input></center<br>
<center><input type="radio" name="ndsem">II</input></center>
</td>
</tr>
<!--<tr>
<td> <font size="5px">Gender </font> </td> 
<td> <center>
<input type="radio" name="r">Male</input><br>
<input type="radio" name="r">Female</input>
</center>
</td>
</tr>-->
<tr>
<td> <font size="5px"> Library </font></td>
<td> Click Button to Send Request </td>
<td> <a href="#" class="sendrequest">Send Request <span class="fa fa-check"></span></a> </td>
<!--<td> <a href="#" class="accept">ACCEPTED <span class="fa fa-check"></span></a>
  <a href="#" class="deny">REJECTED <span class="fa fa-close"></span></a> </td> -->
</tr> 
<tr>
<td> <font size="5px"> LAB1 </font></td>
<td> Click Button to Send Request </td>
<td> <a href="#" class="sendrequest">Send Request <span class="fa fa-check"></span></a> </td>
<!--<td> <a href="#" class="accept">ACCEPTED <span class="fa fa-check"></span></a>
  <a href="#" class="deny">REJECTED <span class="fa fa-close"></span></a> </td> -->
</tr>
<!--<tr>
<td> <font size="5px"> LAB2 </font></td>
<td> Click Button to Send Request </td>
<td> <a href="#" class="sendrequest">Send Request <span class="fa fa-check"></span></a> </td>
<!--<td> <a href="#" class="accept">ACCEPTED <span class="fa fa-check"></span></a>
  <a href="#" class="deny">REJECTED <span class="fa fa-close"></span></a> </td> -->
</tr> 
<!--<tr>
<td> <font size="5px"> LAB3 </font></td>
<td> Click Button to Send Request </td>
<td> <a href="#" class="sendrequest">Send Request <span class="fa fa-check"></span></a> </td>
<!--<td> <a href="#" class="accept">ACCEPTED <span class="fa fa-check"></span></a>
  <a href="#" class="deny">REJECTED <span class="fa fa-close"></span></a> </td> -->
</tr>
<tr>
<td> <font size="5px"> Account Section </font></td>
<td> Click Button to Send Request </td>
<td> <a href="#" class="sendrequest">Send Request <span class="fa fa-check"></span></a> </td>
<!--<td> <a href="#" class="accept">ACCEPTED <span class="fa fa-check"></span></a>
  <a href="#" class="deny">REJECTED <span class="fa fa-close"></span></a> </td> -->
</tr>
<!--<tr>
<td> <font size="5px"> HOD </font></td>
<td> Click Button to Send Request </td>
<td> <a href="#" class="sendrequest">Send Request <span class="fa fa-check"></span></a> </td>
<!--<td> <a href="#" class="accept">ACCEPTED <span class="fa fa-check"></span></a>
  <a href="#" class="deny">REJECTED <span class="fa fa-close"></span></a> </td> -->
</tr>
<!--<tr>
<td colspan="4" > <input type="checkbox" > I accept the <a href="a">Terms of Use </a> & <a href="d"> Privacy Policy. </a></font></td>
</tr>-->
<tr>
<td colspan="4"> <center><input type="submit" name="submit" value="submit"/>
<!--<td><button type="button" disabled onclick="window.print()">Print this page</button></td>-->



</tr>



<table>
</form>
</body>
</head>
</html>
