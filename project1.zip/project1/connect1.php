<?php

$name = filter_input(INPUT_POST, 'name');
$rollno = filter_input(INPUT_POST, 'rollno');
$email = filter_input(INPUT_POST, 'email');
$password = filter_input(INPUT_POST, 'password');
$dob = filter_input(INPUT_POST, 'dob');
$phone = filter_input(INPUT_POST, 'phone');
$dept = filter_input(INPUT_POST, 'dept');
$year = filter_input(INPUT_POST, 'year');
$sem = filter_input(INPUT_POST, 'sem');
$gen = filter_input(INPUT_POST, 'gen');


//if(!empty($rollno)){
//if(!empty($name)){
$host = "localhost";
$dbusername = "root";
$dbpassword = "";
$dbname = "project2";

$conn = new mysqli ($host, $dbusername, $dbpassword, $dbname);

if(mysqli_connect_error()){
	die('Connect Error('.mysqli_connect_errno().')'
	.mysqli_connect_error());
}
else {
//	$sql = "INSERT INTO placement (rollno, name, branch, company, year) values ('$rollno','$name','$branch','$company', '$year')";
	
 // $sql=	"INSERT INTO `placement`(`rollno`, `name`, `branch`, `company`, `year`) VALUES ('$rollno','$name','$branch','$company','$year')";
	
	$sql="INSERT INTO `stureg`(`name`, `rollno`, `email`, `password`, `dob`, `phone`, `dept`, `year`, `sem`, `gen`) VALUES ('$name','$rollno','$email','$password','$dob','$phone', '$dept', '$year', '$sem', '$gen')";
	
//	echo "success";
	
	if($conn->query($sql)){
		
	header("Location:Student_login.php");
		
}
else {
	echo "Error:".$sql."<br>".$conn->error;
		
}	
$conn->close();	
}
	
?>