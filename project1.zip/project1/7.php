<?php
$host = "localhost";
$dbusername = "root";
$dbpassword = "";
$dbname = "project2";

$conn = new mysqli ($host, $dbusername, $dbpassword, $dbname);

if(mysqli_connect_error()){
	die('Connect Error('.mysqli_connect_errno().')'
	.mysqli_connect_error());
}

?>

<!DOCTYPE html>
<html>
<head>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <style>
  body {
  margin: 0;
  background: #ecfab9;
} 
.btn-group button {
  background-color: #04AA6D; /* Green background */
  border: 1px solid green; /* Green border */
  color: white; /* White text */
  padding: 10px 24px; /* Some padding */
  cursor: pointer; /* Pointer/hand icon */
  float: left; /* Float the buttons side by side */
}

/* Clear floats (clearfix hack) */
.btn-group:after {
  content: "";
  clear: both;
  display: table;
}

.btn-group button:not(:last-child) {
  border-right: none; /* Prevent double borders */
}

/* Add a background color on hover */
.btn-group button:hover {
  background-color: #3e8e41;
}
</style>
</head>
<body>
<div class="container">
 <div class="row">
   <div class="col-sm-8">
    
    <div class="table-responsive">
      <table class="table table-bordered" border="3px" cellpadding="10px" cellspacing="15px">
        <tr>
    			  <thead>
			  <tr>
				<th>Student Name</th>
				<th>Student Registration Number</th>
				<th>status</th>
				<th colspan="2"> Action</th>
				
				
			  </tr>
			  </thead>
			  
			  <tbody>
	
				<?php
					$sql="SELECT ndname,ndrollno,status FROM `nodueform` WHERE `status`= '0'";
					$query=mysqli_query($conn,$sql);
					$ndname=$ndrollno=$status=array();
					while($ex=mysqli_fetch_array($query))
					{
						$ndname[]=$ex['ndname'];
						$ndrollno[]=$ex['ndrollno'];
						$status[]=$ex['status'];
						
					}
					for($i=0;$i<sizeof($ndname);$i++)
					{
						$sno=$i+1;
						echo "<tr>";
						echo "<td>$ndname[$i]</td>";
						echo "<td>$ndrollno[$i]</td>";
						echo "<td>$status[$i]</td>";
						//echo "</tr>";
						?>
						
						<td><a href="reject.php" class="btn btn-danger btn-sm" name="UPDATE" >Reject</a> </td>
					
						<td><a href="accept.php" class="btn btn-success btn-sm" name="UPDATE">Accept</a> </td>
					   <?php  echo "</tr>";
					}
					?>
					
					</tbody>
					
					
			  
			</table>
         </tr>
     
        		
     </div>
</div>
</div>
</div>
</body>
</html>

