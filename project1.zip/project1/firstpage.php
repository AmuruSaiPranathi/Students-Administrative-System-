<html>
<head>
</head>
<body> 
<style>
body {
background-image: url(images/firstpage.jpg); 
background-size: cover ;
background-repeat: no-repeat;
opacity: 1;
}
img {
  opacity: 1.0;
}
</style>
<center>
<b><font color="#fcf803" size="35px">Rajeev Gandhi Memorial College of Engineering and Technology</center>
<center>(AUTONOMOUS)</center>
<center>NANDYAL - 518501, KURNOOL DIST., A.P. </font></center></b>
<table cellspacing="50" align="right">
<tr>
<td>
<a href="HomePage.php"><font size="5px" color="#f5f5f5">LOGIN</font></a> </td>
<td><a href="regmain.php"><font size="5px" color="#f5f5f5">RIGISTER</font></a></td>
<td><a href="contactmodule.php"><font size="5px" color="#f5f5f5">CONTACT</font></a></td>
</tr>
</table>
<img src="images/csedept.jpg" alt="students page" align="center" height="500px" width="1000px">
</body>