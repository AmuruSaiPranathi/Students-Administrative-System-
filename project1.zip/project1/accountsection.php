<html>
<head> 
<center>
<h1>Account Section</h1> </center>
<style>
body {
  margin: 0;
  background: #a9ebc3;
}
a{
  text-decoration: none;
}
.accept {
  color: #FFF;
  background: #44CC44;
  padding: 15px 20px;
  box-shadow: 0 4px 0 0 #2EA62E;
}
.accept:hover {
  background: #6FE76F;
  box-shadow: 0 4px 0 0 #7ED37E;
}
.deny {
  color: #FFF;
  background: tomato;
  padding: 15px 20px;
  box-shadow: 0 4px 0 0 #CB4949;
}
.deny:hover {
  background: rgb(255, 147, 128);
  box-shadow: 0 4px 0 0 #EF8282;
}
</style>
</head>
<body>
<center>
<table border="3px" cellpadding="10px" cellspacing="15px" >
<tr>
<th> <b> Student Registration Number </b></th>
<th> <b>&nbsp;&nbsp;&nbsp;&nbsp;Student Name&nbsp;&nbsp;&nbsp;&nbsp; </b></th>
<th> <b> &nbsp;&nbsp;Fee Balance&nbsp;&nbsp; </b> </th>
<th>
  <a href="#" class="accept">ACCEPT <span class="fa fa-check"></span></a>
  <a href="#" class="deny">DENY <span class="fa fa-close"></span></a>
</th>
</tr>
<tr>
<th>  </th>
<th>  </th>
<th>  </th>
<th>
  <a href="#" class="accept">ACCEPT <span class="fa fa-check"></span></a>
  <a href="#" class="deny">DENY <span class="fa fa-close"></span></a>
</th>
</tr>
<tr>
<th>  </th>
<th>  </th>
<th>  </th>
<th>
  <a href="#" class="accept">ACCEPT <span class="fa fa-check"></span></a>
  <a href="#" class="deny">DENY <span class="fa fa-close"></span></a>
</th>
</tr>
<tr>
<th>  </th>
<th>  </th>
<th>  </th>
<th>
  <a href="#" class="accept">ACCEPT <span class="fa fa-check"></span></a>
  <a href="#" class="deny">DENY <span class="fa fa-close"></span></a>
</th>
</tr>
<tr>
<th>  </th>
<th>  </th>
<th>  </th>
<th>
  <a href="#" class="accept">ACCEPT <span class="fa fa-check"></span></a>
  <a href="#" class="deny">DENY <span class="fa fa-close"></span></a>
</th>
</tr>
<tr>
<th>  </th>
<th>  </th>
<th>  </th>
<th>
  <a href="#" class="accept">ACCEPT <span class="fa fa-check"></span></a>
  <a href="#" class="deny">DENY <span class="fa fa-close"></span></a>
</th>
</tr>
<tr>
<th>  </th>
<th>  </th>
<th>  </th>
<th>
  <a href="#" class="accept">ACCEPT <span class="fa fa-check"></span></a>
  <a href="#" class="deny">DENY <span class="fa fa-close"></span></a>
</th>
</tr>
<tr>
<th>  </th>
<th>  </th>
<th>  </th>
<th>
  <a href="#" class="accept">ACCEPT <span class="fa fa-check"></span></a>
  <a href="#" class="deny">DENY <span class="fa fa-close"></span></a>
</th>
</tr>
<tr>
<th>  </th>
<th>  </th>
<th>  </th>
<th>
  <a href="#" class="accept">ACCEPT <span class="fa fa-check"></span></a>
  <a href="#" class="deny">DENY <span class="fa fa-close"></span></a>
</th>
</tr>
<tr>
<th>  </th>
<th>  </th>
<th>  </th>
<th>
  <a href="#" class="accept">ACCEPT <span class="fa fa-check"></span></a>
  <a href="#" class="deny">DENY <span class="fa fa-close"></span></a>
</th>
</tr>
<tr>
<th>  </th>
<th>  </th>
<th>  </th>
<th>
  <a href="#" class="accept">ACCEPT <span class="fa fa-check"></span></a>
  <a href="#" class="deny">DENY <span class="fa fa-close"></span></a>
</th>
</tr>
<tr>
<th>  </th>
<th>  </th>
<th>  </th>
<th>
  <a href="#" class="accept">ACCEPT <span class="fa fa-check"></span></a>
  <a href="#" class="deny">DENY <span class="fa fa-close"></span></a>
</th>
</tr>
</table>
</body>
