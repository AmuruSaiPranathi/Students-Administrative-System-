<?php

$ndname = filter_input(INPUT_POST, 'ndname');
$ndrollno = filter_input(INPUT_POST, 'ndrollno');
//$email = filter_input(INPUT_POST, 'email');
//$password = filter_input(INPUT_POST, 'password');
//$dob = filter_input(INPUT_POST, 'dob');
$ndphone = filter_input(INPUT_POST, 'ndphone');
$ndbranch = filter_input(INPUT_POST, 'ndbranch');
$ndyear = filter_input(INPUT_POST, 'ndyear');
$ndsem = filter_input(INPUT_POST, 'ndsem');
//$gen = filter_input(INPUT_POST, 'gen');


//if(!empty($rollno)){
//if(!empty($name)){
$host = "localhost";
$dbusername = "root";
$dbpassword = "";
$dbname = "project2";

$conn = new mysqli ($host, $dbusername, $dbpassword, $dbname);

if(mysqli_connect_error()){
	die('Connect Error('.mysqli_connect_errno().')'
	.mysqli_connect_error());
}
else {
	
//$sql="INSERT INTO `nodueform`(`ndname`, `ndrollno`, `ndphone`, `ndbranch`, `ndyear`, `ndsem`, `status`) VALUES ('$ndname','$ndrollno','$ndphone', '$ndbranch', '$ndyear', '$ndsem','0')";

$sql = "INSERT INTO `nodueform`(`ndname`, `ndrollno`, `ndphone`, `ndyear`, `ndbranch`, `ndsem`, `status`) VALUES ('$ndname','$ndrollno','$ndphone', '$ndyear', '$ndbranch', '$ndsem', '0')";


	
	if($conn->query($sql)){
		
	header("Location:hallticket.php");
	//echo "success";
		
}
else {
	echo "Error";
		
}	
$conn->close();	
}
?>