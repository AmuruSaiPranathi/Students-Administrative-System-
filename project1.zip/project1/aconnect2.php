<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "project2";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
if(isset($_REQUEST["submit"]))
{
	$email=$_REQUEST["email"];
	$pass=$_REQUEST["pass"];
	
	//$query="SELECT * FROM `reg` WHERE password='$pass'";
	$query="SELECT * FROM `adminreg` WHERE email='$email' and pass='$pass'";
	$result = $conn->query($query);
	//$rowcount=mysql_num_rows($result);
	if($result->num_rows > 0)
	{
		//echo "username and password is correct";
		header("Location:66.php");
		//echo "success";
		
	}
	else
	{
			//echo "invalid ";
			header("Location:66.php");
	}
}

?>