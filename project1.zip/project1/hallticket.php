<html>
<head>
</head>
<body>
<style>
td
{
    text-align:center;
}
</style>
<img src="images/rgmlogohall.jpg" align="left" alt="RGM LOGO" width="100" height="110">
<center><h1><font>RAJEEV GANDHI MEMORIAL COLLEGE OF ENGINEERING AND TECHNOLOGY</h1></center>
<center><h1>(AUTONOMOUS)</h1></center>
<center><h1>NANDYAL - 518501, KURNOOL DIST., A.P. </h1></center>
<center><h1>HALL TICKET  (ORIGINAL) </h1></center>
<ol>
<font size="5px">
<li> Name of the Examination : III B.Tech. II Sem. (R19)(Autonomous) Regural </li>
<li> HTNO : 19091A05C3</li>
<li> Name of the Candidate : AMURU SAI PRANATHI</li>
<li> Father Name : AMURU RAJA SEKHAR REDDY</li>
<li> Mother Name : YELUGOTI CHANDRAKALAVATHI</li>
<li> Month & Year of Exam : JULY 2022</li>
<li> Examination Center : RGMCET(Autonomous),NANDYAL
<center>
<table border="5px" cellpadding="20px" cellspacing="10px">
<tr>
<td colspan="8"> Details Of Subject</td>
</tr>
<tr>
<td>S.no</td>
<td>Code</td>
<td>Name of the Subject</td>
<td>Date of the Exam</td>
<td>S.no</td>
<td>Code</td>
<td>Name of the Subject</td>
<td>Date of the Exam</td>
</tr>
<tr>
<td>1</td>
<td>A001</td>
<td>C# .NET FRAMEWORK</td>
<td>04-07-2022</td>
<td>5</td>
<td>A005</td>
<td>CTC(COLLEGE TO CORPORATE)</td>
<td>12-07-2022</td>
</tr>
<tr>
<td>2</td>
<td>A002</td>
<td>DWM(DATA WAREHOUSING AND MINING)</td>
<td>06-07-2022</td>
<td>6</td>
<td>A006</td>
<td>AP(ANDROID PROGRAMMING) LAB</td>
<td> 14-07-2022</td>
</tr>
<tr>
<td>3</td>
<td>A003</td>
<td>AP(ANDROID PROGRAMMING)</td>
<td> 08-07-2022</td>
<td>7</td>
<td>A007</td>
<td>LAB1 C# .NET</td>
<td> 16-07-2022</td>
</tr>
<tr>
<td>4</td>
<td>A004</td>
<td>CLOUD INFRASTRUCTURE (CIS)</td>
<td>10-07-2022 </td>
<td>8</td>
<td>A008</td>
<td>COMPREHENSIVE VIVA</td>
<td> 18-07-2022</td>
</tr>
</table>
</center>
<h4><u>INSTRUCTIONS TO STUDENTS :</u></h4>
<ol>
<li>Students should come before 10 mins to examination hall</li>
<li>Must carry their Hall Tickets</li>
<li>Should get their own Belongings</li>
<li>Digital Watches are not allowed </li>
</ol>
<table align="right">
<tr>
<td colspan "8"><button type="button"  onclick="window.print()">Print this page</button></td></tr>
</table>
</body>





