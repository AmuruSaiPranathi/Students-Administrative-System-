<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "project2";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
if(isset($_REQUEST["submit"]))
{
	$name=$_REQUEST["name"];
	$password=$_REQUEST["password"];
	
	//$query="SELECT * FROM `reg` WHERE password='$pass'";
	$query="SELECT `name` FROM `facultyreg` WHERE name='$name' and password='$password'";
	$result = $conn->query($query);
	//$rowcount=mysql_num_rows($result);
	if($result->num_rows > 0)
	{
		//echo "username and password is correct";
		header("Location:7.php");
		
	}
	else
	{
			echo "invalid ";
	}
}

?>