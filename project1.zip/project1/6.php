<?php
$ndname = filter_input(INPUT_POST, 'ndname');
$ndrollno = filter_input(INPUT_POST, 'ndrollno');
$status = filter_input(INPUT_POST, 'status');
if(!empty($ndrollno)){
if(!empty($ndname)){
$host = "localhost";
$dbusername = "root";
$dbpassword = "";
$dbname = "project2";
$conn = new mysqli ($host, $dbusername, $dbpassword, $dbname);
if(mysqli_connect_error()){
	die('Connect Error('.mysqli_connect_errno().')'
	.mysqli_connect_error());
}
else {
  $sql="INSERT INTO `nodueform`(`ndname`, `ndrollno`, `status`) VALUES ('$ndname','$ndrollno','0')";
	
	if($conn->query($sql)){
		echo "Suuccessfully record the data";
	}
	else {
		echo "Error:".$sql."<br>".$conn->error;
		
	}	
$conn->close();	
}
}
}
?>