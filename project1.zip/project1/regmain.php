<html>
<body>
<style>
body {
background-image: url(images/rgmmain.jpg); 
background-size: cover ;
background-repeat: no-repeat;
}
</style>
<style> 
*{
box-sizing:border-box;
}
.column{
float:left;
width:33%;
padding:50px;
}
.row::after{
content:"";
clear:both;
display:table;
}
</style>
<br>
<br>
<br>
<center>
<b><h1><font color="#b355c2">Rajeev Gandhi Memorial College of Engineering and Technology</font></h1>
<br>
<br>
<br>
<b><p><h1><font color="#9e377e">Register As </font></h1></p></b>
<br>
<br>
<br>
<div class = "row">
<div class = "column">
<a href = "Student_login.php">
<img src = "images/studentimage.jpg" alt = "student"  width = "160" height = "160">
<figcaption><h1>Student</h1></figcaption>
</a>
</div>
<div class = "column">
<a href = "faculty_login.php">
<img src = "images/facultyimage.jpg" alt = "Faculty"  width = "160" height = "160">
<figcaption><h1>Faculty</h1></figcaption>
</a>
</div>
</center>
</body>
</html>
