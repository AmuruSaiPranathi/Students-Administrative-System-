<html>
<head>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <style>
  body {
  margin: 0;
  background: #ecfab9;
} 
.btn-group button {
  background-color: #04AA6D; /* Green background */
  border: 1px solid green; /* Green border */
  color: white; /* White text */
  padding: 10px 24px; /* Some padding */
  cursor: pointer; /* Pointer/hand icon */
  float: left; /* Float the buttons side by side */
}

/* Clear floats (clearfix hack) */
.btn-group:after {
  content: "";
  clear: both;
  display: table;
}

.btn-group button:not(:last-child) {
  border-right: none; /* Prevent double borders */
}

/* Add a background color on hover */
.btn-group button:hover {
  background-color: #3e8e41;
}
</style>
</head>
<body>

<!--<h2>HTML Forms</h2>

<form action="6.php" method="POST">
  <label for="fname">Faculty Name:</label><br>
  <input type="text" name="fname"><br>
  <label for="lname">Lab Name:</label><br>
  <input type="text" name="lab" ><br><br>
  <input type="submit" value="Submit">
</form> -->

<?php

$host = "localhost";
$dbusername = "root";
$dbpassword = "";
$dbname = "project2";

$conn = new mysqli ($host, $dbusername, $dbpassword, $dbname);
?>
  <div class="table-responsive">
  <center>
 <table class="table table-bordered" border="3px" cellpadding="10px" cellspacing="15px">
        <tr>
    			  <thead>
			  <tr>
				<th>Student Name</th>
				<th>Student Registration Number</th>
				<!--<th>status</th>-->
				<th colspan="2"> Action</th>
				
				
			  </tr>
			  </thead>
			    <tbody>
			 <?php 
			
					$sql="SELECT ndname,ndrollno FROM `nodueform` WHERE `status`= '1'";
					$query=mysqli_query($conn,$sql);
					$ndname=$ndrollno=$status=array();
					while($ex=mysqli_fetch_array($query))
					{
						$ndname[]=$ex['ndname'];
						$ndrollno[]=$ex['ndrollno'];
						//$status[]=$ex['status'];
						
					}
					for($i=0;$i<sizeof($ndname);$i++)
					{
						$sno=$i+1;
						echo "<tr>";
						echo "<td>$ndname[$i]</td>";
						echo "<td>$ndrollno[$i]</td>";
						//echo "<td>$status[$i]</td>";
											
					//echo "</tr>";
						?>
								
						<!--<td><a href="" class="btn btn-success btn-sm" name="accept">Accepted</a> </td>-->
						<td><a href="accept.php" class="btn btn-success btn-sm" name="UPDATE">Accepted</a> </td>
						
					   <?php  echo "</tr>";
					}
					?>
				
				<?php 
			
					$sql="SELECT ndname,ndrollno FROM `nodueform` WHERE `status`= '0'";
					$query=mysqli_query($conn,$sql);
					$ndname=$ndrollno=$status=array();
					while($ex=mysqli_fetch_array($query))
					{
						$ndname[]=$ex['ndname'];
						$ndrollno[]=$ex['ndrollno'];
						//$status[]=$ex['status'];
						
					}
					for($i=0;$i<sizeof($ndname);$i++)
					{
						$sno=$i+1;
						echo "<tr>";
						echo "<td>$ndname[$i]</td>";
						echo "<td>$ndrollno[$i]</td>";
						//echo "<td>$status[$i]</td>";
											
					//echo "</tr>";
						?>
								
						<!--<td><a href="" class="btn btn-success btn-sm" name="accept">Rejected</a> </td>-->
						<td><a href="" class="btn btn-danger btn-sm" name="UPDATE" >Rejected</a> </td>
					   <?php  echo "</tr>";
					}
					?>
					</tbody>
					
					
			  
			</table>
			</center>
         </tr>
     

</body>
</html>
